package com.example.carmanage;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class CarmanageApplicationTests {

	@Test
	void contextLoads() {
	}

}
