package com.example.carmanage.controller;

import com.example.carmanage.entity.Car;
import com.example.carmanage.service.CarService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import java.util.List;
import java.util.Optional;

@RestController
public class CarController {
    @Autowired
    private CarService carServ;

    @PostMapping("/create")
    public ResponseEntity<Car> makeCar(@RequestBody Car car){
        return carServ.createCar(car);
    }

    @GetMapping("/getCars")
    public ResponseEntity<List<Car>> getCar(){
        return carServ.getAllCars();
    }

    @GetMapping("/getCar/{carId}")
    public ResponseEntity<Optional<Car>> getCarById(@PathVariable int carId){
        Optional<Car> car = carServ.getCarById(carId).getBody();

        if (car.isEmpty()) {
            return new ResponseEntity<>(HttpStatus.NOT_FOUND);
        } else {
            return new ResponseEntity<>(car, HttpStatus.OK);
        }

    }
}
