package com.example.carmanage;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class CarmanageApplication {

	public static void main(String[] args) {
		SpringApplication.run(CarmanageApplication.class, args);
	}

}
