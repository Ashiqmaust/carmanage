package com.example.carmanage.service;

import com.example.carmanage.entity.Car;
import com.example.carmanage.repository.CarRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.stereotype.Service;

import java.util.List;
import java.util.Optional;

@Service
public class CarService {
    @Autowired
    private CarRepository carRepo;

    public ResponseEntity<Car> createCar(Car car){
        Car saved=carRepo.save(car);
        return new ResponseEntity<>(saved,HttpStatus.CREATED);
    }

    public ResponseEntity<List<Car>> getAllCars(){
        List<Car> c=carRepo.findAll();
        return new ResponseEntity<>(c,HttpStatus.OK);
    }

    public ResponseEntity<Optional<Car>> getCarById(int carId){
       Optional<Car> c=carRepo.findById(carId);
       if(c.isEmpty()){
           return new ResponseEntity<>(HttpStatus.NOT_FOUND);
       }
       else
           return new ResponseEntity<>(c,HttpStatus.OK);

    }




}
